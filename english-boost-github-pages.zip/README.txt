English Boost – version GitHub Pages

À mettre à la racine d'un dépôt GitHub :
- index.html
- style.css
- app.js

Puis Settings > Pages > Deploy from a branch > main / root.

IMPORTANT : l'aperçu de fichiers HTML dans ChatGPT peut bloquer JavaScript.
Les boutons fonctionnent quand les fichiers sont servis comme un site web (GitHub Pages, serveur local, etc.).
